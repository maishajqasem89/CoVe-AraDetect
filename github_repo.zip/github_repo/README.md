# CoVe-AraDetect

**Verification-Augmented Arabic Misinformation Detection via Chain-of-Verification**

> First application of Chain-of-Verification (CoVe) to Arabic fake news detection on AraFacts.  
> Achieves macro F1 = 0.655 — statistically comparable to AraBERT — without GPU or fine-tuning.

---

## 📄 Paper

> *"Verification-Augmented Arabic Misinformation Detection: A Chain-of-Verification Feature Framework with Pragmatic and Stylometric Signals on AraFacts"*  
> ECE 768 Generative AI Research Project · Spring 2026

---

## 🗂️ Repository Structure

```
CoVe-AraDetect/
├── src/
│   ├── features/
│   │   ├── pragmatic_extractor.py     # 26 Arabic pragmatic features
│   │   ├── stylometric_extractor.py   # 25 stylometric features
│   │   └── cove_pipeline.py           # CoVe verification pipeline (GPT-4o-mini)
│   ├── models/
│   │   └── classifier.py              # XGBoost / RF / LR classifiers
│   └── utils/
│       ├── preprocessing.py           # Arabic text normalization
│       └── caching.py                 # CoVe result caching
├── notebooks/
│   └── Wafaa.ipynb                    # Full experiment notebook (Google Colab)
├── configs/
│   └── config.yaml                    # All hyperparameters and paths
├── requirements.txt
├── .env.example                       # API key template (never commit real keys)
└── README.md
```

---

## 🚀 Quick Start

### 1. Clone and Install

```bash
git clone https://github.com/maishajqasem89/CoVe-AraDetect.git
cd CoVe-AraDetect
pip install -r requirements.txt
```

### 2. Set API Key

```bash
cp .env.example .env
# Edit .env and add your OpenAI API key
```

### 3. Get AraFacts Dataset

AraFacts is publicly available at:  
🔗 https://github.com/firojalam/COVID-19-Arabic-and-English-Dataset  
or request from the authors: Ali et al. (2021), WANLP @ ACL

Place the dataset at: `data/raw/arafacts.csv`

### 4. Run the Pipeline

```bash
# Step 1: Preprocess
python src/utils/preprocessing.py

# Step 2: Extract features (pragmatic + stylometric — no API needed)
python src/features/pragmatic_extractor.py
python src/features/stylometric_extractor.py

# Step 3: Run CoVe (requires OpenAI API key, ~$1.99 for full dataset)
python src/features/cove_pipeline.py

# Step 4: Train classifier
python src/models/classifier.py
```

Or run everything in **Google Colab**:  
[![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/maishajqasem89/CoVe-AraDetect/blob/main/notebooks/Wafaa.ipynb)

---

## 📊 Results

### Binary Classification (Real vs. Fake) — AraFacts Test Set

| Model | Macro F1 | Accuracy | GPU Required |
|-------|----------|----------|--------------|
| XGBoost (CoVe-AraDetect) | **0.655** | 0.778 | ❌ |
| RandomForest | 0.560 | 0.768 | ❌ |
| Logistic Regression | 0.610 | 0.677 | ❌ |
| AraBERT (baseline) | 0.650 | 0.707 | ✅ |

### Ablation Study

| Feature Configuration | Macro F1 |
|----------------------|----------|
| Pragmatic only | 0.491 |
| Stylometric only | 0.491 |
| **CoVe only** | **0.542** |
| Prag + Stylo | 0.566 |
| Prag + CoVe | 0.601 |
| Stylo + CoVe | 0.609 |
| **Prag + Stylo + CoVe (ALL)** | **0.609** |

---

## ⚙️ Feature Groups

| Group | Dimensions | Description |
|-------|-----------|-------------|
| Pragmatic | 26 | Arabic hedge/booster/evidentiality/emotion markers |
| Stylometric | 25 | Character, word, sentence, punctuation statistics |
| CoVe | 12 | Verification signals from GPT-4o-mini |
| **Total** | **63** | Unified interpretable feature vector |

---

## 💰 CoVe Cost

| Split | Claims | API Calls | Cost |
|-------|--------|-----------|------|
| Train | 3,174 | 3,174 | ~$1.40 |
| Val | 680 | 680 | ~$0.30 |
| Test | 681 | 681 | ~$0.29 |
| **Total** | **4,535** | **4,535** | **~$1.99** |

> Results are cached per-claim (MD5-keyed JSON). Re-runs are free.

---

## 🔧 Configuration

Edit `configs/config.yaml`:

```yaml
model:
  cove_model: "gpt-4o-mini"
  max_atomic_claims: 2
  batch_size: 5
  seed: 42

classifier:
  n_estimators: 300
  max_depth: 6
  learning_rate: 0.05
  subsample: 0.8
  colsample_bytree: 0.8

paths:
  data_raw: "data/raw/arafacts.csv"
  data_processed: "data/processed/"
  models: "models/"
  cache: "data/cove_cache/"
```

---

## 📦 Requirements

See `requirements.txt`. Key dependencies:

- `openai>=1.0`
- `xgboost>=1.7`
- `scikit-learn>=1.2`
- `transformers>=4.30` (AraBERT baseline only)
- `pyarabic>=0.6`
- `pandas`, `numpy`, `tqdm`, `asyncio`

---

## 📝 Citation

If you use this code, please cite:

```bibtex
@article{cove_aradetect_2025,
  title={Verification-Augmented Arabic Misinformation Detection: 
         A Chain-of-Verification Feature Framework with 
         Pragmatic and Stylometric Signals on AraFacts},
  author={Anonymous},
  journal={ECE 768 Generative AI Research Project},
  year={2025}
}
```

---

## 🙏 Acknowledgements

- AraFacts dataset: Ali et al. (2021), WANLP @ ACL
- CoVe methodology: Dhuliawala et al. (2024), ACL Findings
- AraBERT: Antoun et al. (2020), aubmindlab

---

## 📄 License

MIT License — see [LICENSE](LICENSE) for details.
