"""
Chain-of-Verification (CoVe) Pipeline for Arabic Claim Verification
CoVe-AraDetect — src/features/cove_pipeline.py

Reference: Dhuliawala et al. (2024). Chain-of-Verification Reduces
Hallucination in Large Language Models. ACL Findings 2024.
"""

import os
import json
import asyncio
import hashlib
from pathlib import Path
import pandas as pd
import numpy as np
from openai import AsyncOpenAI
from tqdm.asyncio import tqdm
import yaml

with open("configs/config.yaml") as f:
    CFG = yaml.safe_load(f)

CACHE_DIR = Path(CFG['paths']['cache'])
CACHE_DIR.mkdir(parents=True, exist_ok=True)

SIGNAL_NAMES = [
    "num_atomic_claims", "num_verifiable_claims",
    "num_verified_supported", "num_verified_refuted", "num_unverifiable",
    "ratio_supported", "ratio_refuted", "ratio_unverifiable",
    "avg_confidence", "avg_evidence_quality", "avg_source_reliability",
    "verification_entropy", "overall_verification_score",
]

DECOMPOSE_PROMPT = """أنت محلل متخصص في التحقق من المعلومات.
قسّم الادعاء التالي إلى {max_atomic} ادعاءات جوهرية قابلة للتحقق.
اكتب كل ادعاء في سطر منفصل بدون ترقيم.
الادعاء: {claim}
الادعاءات الجوهرية:"""

VERIFY_PROMPT = """أنت محقق متخصص في التحقق من المعلومات العربية.
بناءً على الوصف التالي كمصدر للأدلة، قيّم الادعاء الجوهري.
الوصف (الأدلة): {description}
الادعاء الجوهري: {atomic_claim}
قيّم بـ:
- الحكم: [مدعوم / مرفوض / غير قابل للتحقق]
- الثقة (0.0-1.0):
- جودة الأدلة (0.0-1.0):
- موثوقية المصدر (0.0-1.0):
أجب بتنسيق JSON فقط:
{{"verdict": "...", "confidence": 0.0, "evidence_quality": 0.0, "source_reliability": 0.0}}"""


def get_cache_key(claim: str, description: str) -> str:
    return hashlib.md5(f"{claim}|||{description}".encode()).hexdigest()


def load_cache(key: str):
    f = CACHE_DIR / f"{key}.json"
    if f.exists():
        with open(f) as fp:
            return json.load(fp)
    return None


def save_cache(key: str, signals: dict):
    with open(CACHE_DIR / f"{key}.json", "w") as fp:
        json.dump(signals, fp)


async def decompose_claim(client, claim: str, max_atomic: int = 2) -> list[str]:
    prompt = DECOMPOSE_PROMPT.format(claim=claim, max_atomic=max_atomic)
    try:
        resp = await client.chat.completions.create(
            model=CFG['model']['cove_model'],
            messages=[{"role": "user", "content": prompt}],
            max_tokens=300, temperature=0,
        )
        lines = [l.strip() for l in resp.choices[0].message.content.strip().split('\n') if l.strip()]
        return lines[:max_atomic] if lines else [claim]
    except Exception:
        return [claim]


async def verify_atomic(client, atomic: str, description: str) -> dict:
    prompt = VERIFY_PROMPT.format(atomic_claim=atomic, description=description or "لا يوجد وصف متاح")
    try:
        resp = await client.chat.completions.create(
            model=CFG['model']['cove_model'],
            messages=[{"role": "user", "content": prompt}],
            max_tokens=200, temperature=0,
        )
        text = resp.choices[0].message.content.strip()
        text = text.replace("```json", "").replace("```", "").strip()
        return json.loads(text)
    except Exception:
        return {"verdict": "غير قابل للتحقق", "confidence": 0.5, "evidence_quality": 0.5, "source_reliability": 0.5}


def aggregate_signals(verifications: list[dict]) -> dict:
    n = len(verifications)
    if n == 0:
        return {s: 0.0 for s in SIGNAL_NAMES}

    supported  = sum(1 for v in verifications if "مدعوم" in v.get("verdict", ""))
    refuted    = sum(1 for v in verifications if "مرفوض" in v.get("verdict", ""))
    unverif    = sum(1 for v in verifications if "غير قابل" in v.get("verdict", ""))
    verifiable = supported + refuted

    probs = [supported/n, refuted/n, unverif/n]
    entropy = -sum(p * np.log(p + 1e-9) for p in probs)

    return {
        "num_atomic_claims":      n,
        "num_verifiable_claims":  verifiable,
        "num_verified_supported": supported,
        "num_verified_refuted":   refuted,
        "num_unverifiable":       unverif,
        "ratio_supported":        supported / n,
        "ratio_refuted":          refuted / n,
        "ratio_unverifiable":     unverif / n,
        "avg_confidence":         np.mean([v.get("confidence", 0.5) for v in verifications]),
        "avg_evidence_quality":   np.mean([v.get("evidence_quality", 0.5) for v in verifications]),
        "avg_source_reliability": np.mean([v.get("source_reliability", 0.5) for v in verifications]),
        "verification_entropy":   float(entropy),
        "overall_verification_score": (supported - refuted) / n,
    }


async def run_cove(claim: str, description: str = "", max_atomic: int = 2) -> dict:
    key = get_cache_key(claim, description)
    cached = load_cache(key)
    if cached:
        return cached

    client = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))
    atomics = await decompose_claim(client, claim, max_atomic)
    verifs  = await asyncio.gather(*[verify_atomic(client, a, description) for a in atomics])
    signals = aggregate_signals(list(verifs))
    save_cache(key, signals)
    return signals


async def process_dataframe(df: pd.DataFrame, batch_size: int = 5, desc: str = "CoVe") -> pd.DataFrame:
    results, cached_count = [], 0
    client = AsyncOpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    pbar = tqdm(total=len(df), desc=desc)
    for i in range(0, len(df), batch_size):
        batch = df.iloc[i:i+batch_size]
        tasks = []
        for _, row in batch.iterrows():
            key = get_cache_key(row['claim_normalized'], row.get('description_normalized', ''))
            cached = load_cache(key)
            if cached:
                results.append(cached)
                cached_count += 1
                pbar.update(1)
            else:
                tasks.append((row['claim_normalized'], row.get('description_normalized', '')))

        if tasks:
            coros = [run_cove(c, d, CFG['model']['max_atomic_claims']) for c, d in tasks]
            batch_results = await asyncio.gather(*coros)
            results.extend(batch_results)
            pbar.update(len(tasks))
            await asyncio.sleep(0.3)

    pbar.close()
    print(f"   {len(results)} total | {cached_count} cached | {len(results)-cached_count} new API calls")
    return pd.DataFrame(results, columns=SIGNAL_NAMES)


if __name__ == "__main__":
    from dotenv import load_dotenv
    load_dotenv()

    processed = Path(CFG['paths']['data_processed'])
    loop = asyncio.get_event_loop()

    for split in ["train_binary", "val_binary", "test_binary",
                  "train_multiclass", "val_multiclass", "test_multiclass"]:
        df = pd.read_parquet(processed / f"{split}.parquet")
        print(f"\n🔍 Processing {split} ({len(df)} claims)...")
        cove_df = loop.run_until_complete(
            process_dataframe(df, CFG['model']['batch_size'], desc=split)
        )
        cove_df.to_parquet(processed / f"cove_{split}.parquet", index=False)
        print(f"   ✅ Saved cove_{split}.parquet")

    print("\n🎉 CoVe feature extraction complete!")
