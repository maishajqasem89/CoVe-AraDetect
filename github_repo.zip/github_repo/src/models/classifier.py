"""
Classifier Training — CoVe-AraDetect
src/models/classifier.py
"""

import numpy as np
import pandas as pd
import joblib
import yaml
from pathlib import Path
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, f1_score, accuracy_score
from xgboost import XGBClassifier

with open("configs/config.yaml") as f:
    CFG = yaml.safe_load(f)

SEED    = CFG['model']['seed']
PROC    = Path(CFG['paths']['data_processed'])
MODELS  = Path(CFG['paths']['models'])
MODELS.mkdir(parents=True, exist_ok=True)


def load_features(split: str, task: str = "binary") -> pd.DataFrame:
    prag  = pd.read_parquet(PROC / f"prag_{split}_{task}.parquet").add_prefix("prag_")
    stylo = pd.read_parquet(PROC / f"stylo_{split}_{task}.parquet").add_prefix("stylo_")
    cove  = pd.read_parquet(PROC / f"cove_{split}_{task}.parquet").add_prefix("cove_")
    X = pd.concat([prag, stylo, cove], axis=1)
    return X.replace([np.inf, -np.inf], np.nan).fillna(0.0)


def train_binary():
    print("=" * 55)
    print("📗 BINARY: Real vs Fake")
    print("=" * 55)

    X_train = load_features("train", "binary")
    X_val   = load_features("val",   "binary")
    X_test  = load_features("test",  "binary")

    train_df = pd.read_parquet(PROC / "train_binary.parquet")
    val_df   = pd.read_parquet(PROC / "val_binary.parquet")
    test_df  = pd.read_parquet(PROC / "test_binary.parquet")

    y_train = train_df['label_binary'].values
    y_val   = val_df['label_binary'].values
    y_test  = test_df['label_binary'].values

    scaler = StandardScaler()
    X_tr_s = scaler.fit_transform(X_train)
    X_va_s = scaler.transform(X_val)
    X_te_s = scaler.transform(X_test)
    joblib.dump(scaler, MODELS / "scaler_binary.pkl")

    cfg_xgb = CFG['classifier']['xgboost']
    cfg_rf  = CFG['classifier']['random_forest']
    cfg_lr  = CFG['classifier']['logistic_regression']

    pos_weight = (y_train == 0).sum() / (y_train == 1).sum()

    models = {
        "XGBoost": XGBClassifier(
            n_estimators=cfg_xgb['n_estimators'], max_depth=cfg_xgb['max_depth'],
            learning_rate=cfg_xgb['learning_rate'], subsample=cfg_xgb['subsample'],
            colsample_bytree=cfg_xgb['colsample_bytree'], scale_pos_weight=pos_weight,
            use_label_encoder=False, eval_metric='logloss',
            random_state=SEED, n_jobs=-1,
        ),
        "RandomForest": RandomForestClassifier(
            n_estimators=cfg_rf['n_estimators'], max_depth=cfg_rf['max_depth'],
            class_weight=cfg_rf['class_weight'], random_state=SEED, n_jobs=-1,
        ),
        "LogisticRegression": LogisticRegression(
            C=cfg_lr['C'], max_iter=cfg_lr['max_iter'],
            class_weight=cfg_lr['class_weight'], random_state=SEED,
        ),
    }

    results = {}
    for name, model in models.items():
        model.fit(X_tr_s, y_train)
        val_f1  = f1_score(y_val,  model.predict(X_va_s), average='macro')
        test_f1 = f1_score(y_test, model.predict(X_te_s), average='macro')
        acc     = accuracy_score(y_test, model.predict(X_te_s))
        results[name] = {'val_f1': val_f1, 'test_f1': test_f1, 'acc': acc, 'model': model}
        print(f"   {name:<22} | Val F1: {val_f1:.3f} | Test F1: {test_f1:.3f} | Acc: {acc:.3f}")

    best_name  = max(results, key=lambda k: results[k]['val_f1'])
    best_model = results[best_name]['model']
    print(f"\n🏆 Best: {best_name}")
    print(classification_report(y_test, best_model.predict(X_te_s),
                                 target_names=['Fake','Real'], digits=3))
    joblib.dump(best_model, MODELS / f"best_binary_{best_name}.pkl")
    return best_model, scaler, X_te_s, y_test


if __name__ == "__main__":
    train_binary()
    print("\n✅ Training complete! Models saved to", MODELS)
