"""
Arabic Text Preprocessing Pipeline
CoVe-AraDetect — src/utils/preprocessing.py
"""

import re
import pandas as pd
import pyarabic.araby as araby
from pathlib import Path
import yaml

with open("configs/config.yaml") as f:
    CFG = yaml.safe_load(f)

LABEL_BINARY = {
    "True": 1, "Real": 1,
    "False": 0, "Fake": 0,
    "Partly-false": 0, "Sarcasm": 0,
}
LABEL_3CLASS = {
    "True": 0, "Real": 0,
    "Partly-false": 1,
    "False": 2, "Fake": 2, "Sarcasm": 2,
}


def normalize_arabic(text: str) -> str:
    """Full Arabic normalization pipeline."""
    if not isinstance(text, str):
        return ""
    text = araby.strip_tashkeel(text)          # remove diacritics
    text = araby.strip_tatweel(text)           # remove tatweel
    text = araby.normalize_hamza(text)         # normalize hamza variants
    text = araby.normalize_lamalef(text)       # normalize lam-alef
    text = re.sub(r'[أإآا]', 'ا', text)       # unify alef variants
    text = re.sub(r'ة', 'ه', text)            # normalize taa marbuta
    text = re.sub(r'ى', 'ي', text)            # normalize alef maqsura
    text = re.sub(r'http\S+', ' URL ', text)   # replace URLs
    text = re.sub(r'@\w+', ' MENTION ', text)  # replace mentions
    text = re.sub(r'#(\w+)', r' \1 ', text)    # expand hashtags
    text = re.sub(r'(.)\1{3,}', r'\1\1', text) # compress repeated chars
    text = re.sub(r'\s+', ' ', text).strip()   # normalize whitespace
    return text


def load_and_preprocess(path: str) -> pd.DataFrame:
    """Load AraFacts CSV and apply preprocessing."""
    df = pd.read_csv(path)

    # Normalize text
    df['claim_normalized'] = df['claim'].apply(normalize_arabic)
    df['description_normalized'] = df['description'].apply(normalize_arabic)

    # Filter by length
    df['word_count'] = df['claim_normalized'].str.split().str.len()
    df = df[
        (df['word_count'] >= CFG['data']['min_words']) &
        (df['word_count'] <= CFG['data']['max_words'])
    ].copy()

    # Filter out Other/Unverifiable
    valid_labels = list(LABEL_BINARY.keys())
    df = df[df['label'].isin(valid_labels)].copy()

    # Map labels
    df['label_binary'] = df['label'].map(LABEL_BINARY)
    df['label_3class'] = df['label'].map(LABEL_3CLASS)

    df = df.reset_index(drop=True)
    print(f"✅ Loaded {len(df)} claims after filtering")
    print(f"   Binary: {df['label_binary'].value_counts().to_dict()}")
    print(f"   3-class: {df['label_3class'].value_counts().to_dict()}")

    return df


def split_dataset(df: pd.DataFrame, seed: int = 42):
    """Stratified train/val/test split."""
    from sklearn.model_selection import train_test_split

    test_size = CFG['data']['test_size']
    val_size  = CFG['data']['val_size']

    # Binary splits
    train_bin, temp_bin = train_test_split(
        df, test_size=test_size + val_size,
        stratify=df['label_binary'], random_state=seed
    )
    val_bin, test_bin = train_test_split(
        temp_bin,
        test_size=test_size / (test_size + val_size),
        stratify=temp_bin['label_binary'], random_state=seed
    )

    # Multi-class splits
    train_mc, temp_mc = train_test_split(
        df, test_size=test_size + val_size,
        stratify=df['label_3class'], random_state=seed
    )
    val_mc, test_mc = train_test_split(
        temp_mc,
        test_size=test_size / (test_size + val_size),
        stratify=temp_mc['label_3class'], random_state=seed
    )

    out = Path(CFG['paths']['data_processed'])
    out.mkdir(parents=True, exist_ok=True)

    for name, split in [
        ("train_binary", train_bin), ("val_binary", val_bin), ("test_binary", test_bin),
        ("train_multiclass", train_mc), ("val_multiclass", val_mc), ("test_multiclass", test_mc),
    ]:
        split.to_parquet(out / f"{name}.parquet", index=False)

    print(f"\n✅ Splits saved to {out}")
    print(f"   Train: {len(train_bin)} | Val: {len(val_bin)} | Test: {len(test_bin)}")
    return train_bin, val_bin, test_bin, train_mc, val_mc, test_mc


if __name__ == "__main__":
    df = load_and_preprocess(CFG['paths']['data_raw'])
    split_dataset(df, seed=CFG['model']['seed'])
